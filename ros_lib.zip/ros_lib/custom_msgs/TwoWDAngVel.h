#ifndef _ROS_custom_msgs_TwoWDAngVel_h
#define _ROS_custom_msgs_TwoWDAngVel_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace custom_msgs
{

  class TwoWDAngVel : public ros::Msg
  {
    public:
      typedef float _L_type;
      _L_type L;
      typedef float _R_type;
      _R_type R;

    TwoWDAngVel():
      L(0),
      R(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_L;
      u_L.real = this->L;
      *(outbuffer + offset + 0) = (u_L.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_L.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_L.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_L.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->L);
      union {
        float real;
        uint32_t base;
      } u_R;
      u_R.real = this->R;
      *(outbuffer + offset + 0) = (u_R.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_R.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_R.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_R.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->R);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_L;
      u_L.base = 0;
      u_L.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_L.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_L.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_L.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->L = u_L.real;
      offset += sizeof(this->L);
      union {
        float real;
        uint32_t base;
      } u_R;
      u_R.base = 0;
      u_R.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_R.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_R.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_R.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->R = u_R.real;
      offset += sizeof(this->R);
     return offset;
    }

    virtual const char * getType() override { return "custom_msgs/TwoWDAngVel"; };
    virtual const char * getMD5() override { return "46907ddb4ff82feda6e3d9ba77bedd1f"; };

  };

}
#endif
